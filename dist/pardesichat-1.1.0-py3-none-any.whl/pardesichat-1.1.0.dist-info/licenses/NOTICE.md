**License note**

The base application is offered under the MIT license but please refer to the licenses for Gemma and Qwen. 

Gemma is provided under and subject to the Gemma Terms of Use found at ai.google.dev/gemma/terms"

Qwen is subject to the following license agreement: registry.ollama.ai/library/qwen2.5vl:latest/blobs/832dd9e00a68

Please also refer to the license requirements for all the libraries used before you deploy the application. 